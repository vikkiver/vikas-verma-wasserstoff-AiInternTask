# GenAI Guessing Game

How to run, architecture overview, etc.
