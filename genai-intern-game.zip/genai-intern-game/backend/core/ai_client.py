# Handles communication with the GenAI endpoint
