# Redis caching logic
