# Linked list and game rules
