# Profanity and safety filter
