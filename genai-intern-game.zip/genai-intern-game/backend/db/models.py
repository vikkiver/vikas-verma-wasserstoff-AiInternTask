# Database models (SQLAlchemy or similar)
