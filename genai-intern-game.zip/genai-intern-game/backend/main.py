# FastAPI app setup and route registration
