# Test for duplicate guess game-over path
